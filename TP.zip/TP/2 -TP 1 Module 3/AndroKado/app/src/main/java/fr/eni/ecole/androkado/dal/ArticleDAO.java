package fr.eni.ecole.androkado.dal;

import fr.eni.ecole.androkado.bo.Article;

public interface ArticleDAO {
    public Article getFirst();
}
