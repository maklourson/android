package fr.eni.ecole.androkado.bo;

public abstract class UtilsApp {
    public final static String CONFIGURATION = "configuration";
}
